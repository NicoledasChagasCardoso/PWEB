var n1 = prompt("Número 1: ");
var n2 = prompt("Número 2: ");

var numb1 = parseFloat(n1);
var numb2 = parseFloat(n2);

alert("Soma: " + (numb1 + numb2)+
    "\nSubtração: " + (numb1 - numb2)+
    "\nProduto: " + (numb1 * numb2)+
    "\nDivisão: " + (numb1 / numb2)+
    "\nResto da divisão: " + (numb1 % numb2))