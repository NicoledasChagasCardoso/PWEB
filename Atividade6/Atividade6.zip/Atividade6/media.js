var n1 = prompt("Digite a nota 1: ");
var n2 = prompt("Digite a nota 2: ");
var n3 = prompt("Digite a nota 3: ");

var not1 = parseFloat(n1);
var not2 = parseFloat(n2);
var not3 = parseFloat(n3);

var media = (not1 + not2 + not3) / 3;

alert("A média é: " + media);