var sql = require ('mssql/msnodesqlv8'); 

var connSQLServer = function(){ 
const sqlConfig = {
    user: 'Niaoi',
 password: '00022001',
 database: 'BD',
 driver: 'msnodesqlv8',
 options: {
 encrypt: false,
 trustServerCertificate: true,
 }
 } 

return sql.connect(sqlConfig); 
} 

// exportando a função e quando chamar a 
// página ele conecta 
module.exports = function(){ 
    console.log('O autoload carregou o módulo de conexão com o bd'); 
    return connSQLServer; 
   } 
   